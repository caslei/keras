from keras.preprocessing.image import ImageDataGenerator
import os, sys, glob
from keras.models import load_model
import time


def testing(trained_model_path, test_dir):
    """
    Perform detection using trained keras model on color or grayscale images
    :param trained_model: keras mode *.h5 file
    :return: vector of predicted classes for test_images
    """
    start_test = time.time()
    assert (os.path.exists(trained_model_path)), "Invalid model path"
    assert (os.path.exists(test_dir)), "Invalid test image directory path"
    batch_size = 32

    model = load_model(trained_model_path)
    img_shape = model.input.shape[1:3]

    # no data augmentation (except normalize)
    test_gen = ImageDataGenerator(rescale=1. / 255)

    test_generator = test_gen.flow_from_directory(  test_dir,
                                                    target_size=img_shape,
                                                    batch_size=batch_size,
                                                    class_mode="categorical",
                                                    shuffle=True)
    test_loss, test_accuracy = model.evaluate_generator(test_generator)
    test_time = time.time() - start_test

    print("test accuracy = ", test_accuracy)
    print("test time = ", test_time)


def test_demo(dataset_name, model_type):
    data_dir = "D:/Datasets/"
    trained_model_path = "D:/Datasets/model/lung_InceptionV3.h5" #
    test_img_dir = data_dir + dataset_name + "/test/" # "D:/Datasets/lung/test/"
    testing(trained_model_path, test_img_dir)


def main():
    dataset_name = "lung" #"retinal"  # use "retinal" or "lung"
    model_type = 'InceptionV3'  # use InceptionV3 or Resnet50
    test_demo(dataset_name, model_type)


def main_for_each_image():
    test_dir = "D:/Datasets/lung/test/"
    myModel = load_model("D:/Datasets/model/lung_InceptionV3.h5")
    image_fps = glob.glob(test_dir+"/*.jpg")

    f = open("D:/Datasets/model/predict_result.txt", "w")
    f.write("image,target,probability\n")

    for idx, image_fp in enumerate(image_fps):
        print("processing image {:d}".format(idx))
        
        img = image.load_img(image_fp, target_size=(224,224))
        x = image.img_to_array(img)
        x = np.expand_dims(x, axis=0)
        x = x/255. # 需要与训练时的处理保持一致
        prob = myModel.predict(x)[0][1]
        target = [0,1][prob>0.5]

        image_name_without_ext = os.path.splitext(os.path.basename(image_fp))[0]
        f.write("{:s},{:1d},{:4f}\n".format(image_name_without_ext, target, prob))
    f.close()



if __name__ == '__main__':
    main()

