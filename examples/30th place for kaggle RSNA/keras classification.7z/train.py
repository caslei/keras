from utility import Tool
from build_model import Finetune_Model
import keras
from keras.preprocessing.image import ImageDataGenerator
from keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
import os
import time


def training(model, training_img_dir, validation_img_dir, trained_model_path, 
            history_log_dir, history_plot_tag):
    start_train = time.time()
    assert (os.path.exists(training_img_dir)), "Invalid training image directory"
    assert (os.path.exists(validation_img_dir)), "Invalid validation image directory"

    batch_size = 32
    img_shape = model.input.shape[1:3]

    # data augmentation: flip images and rotate images to avoid overfitting 
    train_gen = ImageDataGenerator(
        rotation_range=90,   # range in degress 
        rescale=1. / 255,
        zoom_range = 0.2,
        shear_range = 0.1,
        width_shift_range = 0.05,
        height_shift_range = 0.05,
        horizontal_flip=True,
        vertical_flip=True)

    train_generator = train_gen.flow_from_directory(
        training_img_dir,
        target_size=img_shape,
        batch_size=batch_size,
        class_mode="categorical",
        shuffle=True)

    # no data augmentation (except normalize) , no shuffle for validation set
    val_gen = ImageDataGenerator(rescale=1. / 255)

    val_generator = val_gen.flow_from_directory(
        validation_img_dir,
        target_size=img_shape,
        batch_size=batch_size,
        class_mode="categorical",
        shuffle=True)

    def step_decay(epoch): # for epoch=50
        res = 1.0e-3
        if (epoch > 15) and (epoch <=30):
            res = 1.0e-4
        elif (epoch > 30) and (epoch <=45):
            res = 1.0e-5
        elif (epoch > 45) and (epoch <=60):
            res = 1.0e-6
        elif (epoch > 60):
            res = 1.0e-7    
        print("learnrate: ", res, " epoch: ", epoch)
        return res

    # No early stopping, but only the best model is saved
    callbacks = [   keras.callbacks.ModelCheckpoint(filepath=trained_model_path, monitor='val_loss', save_best_only=True), # , save_weights_only=False
                    keras.callbacks.ReduceLROnPlateau(monitor='val_loss',factor=0.5, patience=10, min_lr=1.0e-7, verbose=1),
                    keras.callbacks.TensorBoard(log_dir=self.log_dir, histogram_freq=0, write_graph=True, write_images=False),
                    # keras.callbacks.LearningRateScheduler(step_decay), # 
                    keras.callbacks.EarlyStopping(monitor='val_loss', min_delta=1.0e-7, patience=25, verbose=2, mode='auto'),
                    keras.callbacks.CSVLogger(os.path.join(self.log_dir, 'csvlogger.csv')),
                ]

    # fits the model on batches with real-time data augmentation:
    history = model.fit_generator(train_generator, epochs=250, validation_data=val_generator, callbacks=callbacks, verbose=1, shuffle=False)

    train_time = time.time() - start_train
    print("train time = ", train_time)

    tool = Tool()
    tool.visualizeTrain(history, history_plot_tag, history_log_dir)

    train_loss, train_accuracy = model.evaluate_generator(train_generator)
    print("train_accuracy", train_accuracy)

    val_loss, val_accuracy = model.evaluate_generator(val_generator)
    print("val_accuracy", val_accuracy)





def train_demo(dataset_name, model_type):
    data_dir = "D:/Datasets/"
    history_log_dir = "D:/Datasets/log/"
    if dataset_name == "retinal":
        num_classes = 4
        class_names = ['t0', 't1', 't2', 't3']

    elif dataset_name == "lung":
        num_classes = 2
        class_names = ['Nmix', 'Pmix']
    
    elif dataset_name == "other":
        pass

    else:
        print("Error: invalid model type")
        return
    split_log = history_log_dir + dataset_name+".txt"      # "D:/Datasets/log/lung.txt'
    training_img_dir = data_dir + dataset_name + "/train/" # "D:/Datasets/lung/train/'
    validation_img_dir = data_dir + dataset_name + "/val/" # "D:/Datasets/lung/val/'
    test_img_dir = data_dir + dataset_name + "/test/"      # "D:/Datasets/lung/test/'

    # "D:/Datasets/model/lung_InceptionV3.h5'
    trained_model_path = data_dir + "model/" + dataset_name + '_' + model_type + ".h5"


    fineTuneModel = Finetune_Model()
    tool = Tool()
    print("training_img_dir", training_img_dir)
    tool.split_data(split_log = split_log, 
                    train_dir=training_img_dir,
                    val_dir=validation_img_dir, 
                    test_dir=test_img_dir, 
                    classes=class_names)
    fineTuneModel.build_model(model_type, num_classes)


    training(model=fineTuneModel.model, training_img_dir=training_img_dir, 
            validation_img_dir=validation_img_dir, trained_model_path=trained_model_path, 
            history_log_dir = history_log_dir, history_plot_tag = dataset_name+"_"+model_type)
    

def main():
    dataset_name = "lung" 
    model_type = 'InceptionV3' 
    train_demo(dataset_name, model_type)


if __name__ == '__main__':
    main()

