""" Pneumonia detection """
import sys
import os
import cv2
import glob
import time
import pydicom
import math
import random
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
from tqdm import tqdm
from imgaug import augmenters as iaa
from keras.callbacks import CSVLogger
from keras.callbacks import EarlyStopping
from keras.callbacks import ReduceLROnPlateau

import utils
import pneu_dataset
import model as modellib
from config import Config

sys.path.append("./toolbox")
import tool



class DetectorConfig(Config):
    """ MRCNN configuration """
    GPU_COUNT = 1
    NUM_CLASSES = 2
    NAME = 'pneumonia'
    BACKBONE = 'resnet101'
    IMAGE_RESIZE_MODE = "square"
    ORIG_SIZE = 512

    IMAGES_PER_GPU = 32 # Batch size
    NUM_EPOCHS = 30
    LEARNING_RATE = 1e-3
    
    IMAGE_MIN_DIM = 512
    IMAGE_MAX_DIM = 512

    TRAIN_STEPS = 1067
    VAL_STEPS = 134

    TRAIN_CSV_FP = "C:/Users/hliu/Desktop/DL/dataset/Kaggle/mrcnn_set/train.csv"
    VAL_CSV_FP = "C:/Users/hliu/Desktop/DL/dataset/Kaggle/mrcnn_set/val.csv"

    # MRCNN
    MAX_GT_INSTANCES = 5
    LOSS_WEIGHTS = {"rpn_class_loss":   1.,
                    "rpn_bbox_loss":    1.,
                    "mrcnn_class_loss": 1.,
                    "mrcnn_bbox_loss":  1.,
                    "mrcnn_mask_loss":  1.}
    
    # RPN branch
    RPN_ANCHOR_SCALES = (32, 64, 128, 256, 512)
    TRAIN_ROIS_PER_IMAGE = 50

    # Mask branch
    MINI_MASK_SHAPE = (28,28)

    # Detection
    DETECTION_MAX_INSTANCES = 10
    DETECTION_MIN_CONFIDENCE = 0.75
    DETECTION_NMS_THRESHOLD = 0.3



def augmentation(num):
    """ Real-time image augmentation """
    return iaa.SomeOf((0,num),
                [    
                iaa.Fliplr(0.5),
                iaa.Flipud(0.5),
                iaa.Affine(scale={"x": (0.8, 1.2), "y": (0.8, 1.2)}, 
                        translate_percent={"x": (-0.1, 0.1), "y": (-0.1, 0.1)}, 
                        rotate=(-25, 25), 
                        shear=(-10, 10)),
                iaa.CropAndPad(percent=(-0.2,0.2)),
                iaa.Add((-10, 10), per_channel=0.5),
                iaa.ContrastNormalization((0.8,1.5),per_channel=0.5),
                iaa.Sharpen(alpha=(0, 1.0), lightness=(0.75, 1.5)),
                iaa.Emboss(alpha=(0, 1.0), strength=(0, 1.5)),
                iaa.Multiply((0.9, 1.1), per_channel=0.5),
                iaa.PerspectiveTransform((0.01, 0.1)),
                iaa.PiecewiseAffine((0.02, 0.04)),
                iaa.ElasticTransformation(alpha=130, sigma=(10,13)),
                iaa.OneOf([
                    iaa.AdditiveGaussianNoise(loc=0, scale=(0.0, 0.05*255), per_channel=0.5),    
                    iaa.Dropout((0.01,0.03)),
                    iaa.SaltAndPepper((0.01,0.02)),
                    ]),
                iaa.OneOf([
                    iaa.GaussianBlur((0, 1.2)),
                    iaa.AverageBlur(k=(1, 5)),
                    iaa.MedianBlur(k=(1, 5)),
                    ]),
                ])



class InferenceConfig(DetectorConfig):
    GPU_COUNT = 1
    IMAGES_PER_GPU = 1



class MyDetector(object):
    def __init__(self):
        self.config = DetectorConfig()
        self.model = None


    def display_config(self):
        self.config.display()


    def get_dataset(self, csv_fp):
            df = pd.read_csv(csv_fp)
            image_fps = tool.get_uniq(df["patientId"].tolist())
            ant = {image_fp: [] for image_fp in image_fps}
            for _,row in df.iterrows():
                ant[row["patientId"]].append(row)
            dataset = pneu_dataset.DetectorDataset(image_fps, ant,
                self.config.ORIG_SIZE, self.config.ORIG_SIZE)
            dataset.prepare()
            return dataset


    def train(self, log_dir):
        """ Training MRCNN 
        """
        #########################################################################
        csv_logger = CSVLogger(os.path.join(log_dir, "csv_logger.csv"))
        early_stop = EarlyStopping(monitor='val_loss', patience=10)
        reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.1, patience=5)
        #########################################################################

        # Make log directory if not exist
        if not os.path.isdir(log_dir): 
            os.makedirs(log_dir)

        train_dataset = self.get_dataset(self.config.TRAIN_CSV_FP)
        val_dataset = self.get_dataset(self.config.VAL_CSV_FP)

        # Load MRCNN model
        model = modellib.MaskRCNN(mode='training', config=self.config, model_dir=log_dir)

        # Initialization
        model.load_weights(filepath=model.get_imagenet_weights(), by_name=True)
        
        # Training RPN
        model.train(train_dataset, val_dataset, 
                    learning_rate=1e-3, 
                    epochs=30, 
                    layers='heads',
                    augmentation=augmentation(7),
                    custom_callbacks=[csv_logger, early_stop, reduce_lr]
                    )
        """ fix rpn weights, train only mask heads:
        model.train(train_dataset, val_dataset, 
                    learning_rate=1e-3, 
                    epochs=30, 
                    layers='heads',
                    augmentation=augmentation(7),
                    custom_callbacks=[csv_logger, early_stop, reduce_lr]
                    )
        """

    def load_model(self, weights_fp):
        self.config =InferenceConfig()
        model = modellib.MaskRCNN(mode='inference', config=self.config, model_dir=None)
        model.load_weights(filepath=weights_fp, by_name=True)
        print("successfully loaded MRCNN model")
        self.model = model


    def predict(self, image_fp, show=False, min_conf=0.95):
        """Predict single image.
        Returns: 
        Empty list or [[score1, x1, y1, w1, h1], [score2, x2, ......]
        """
        assert self.model is not None, "Please load model"
        boxes_list = []
        min_dim = self.config.IMAGE_MIN_DIM
        max_dim = self.config.IMAGE_MAX_DIM
        mode = self.config.IMAGE_RESIZE_MODE
        # rf = self.config.ORIG_SIZE/self.config.IMAGE_SHAPE[0]
        rf = self.config.ORIG_SIZE/self.config.IMAGE_SHAPE[0]*2
        image = tool.read_image(image_fp, 3)
        image = tool.normalize(image)
        image, window, scale, padding, crop = utils.resize_image(image,
            min_dim=min_dim, max_dim=max_dim, mode=mode)
        pred = self.model.detect([image])[0]
        num_box = len(pred['rois'])
        assert num_box == len(pred['scores'])
        if num_box != 0:
            for i in range(num_box):
                if pred["scores"][i] > min_conf:
                    score = round(pred['scores'][i],2)
                    x = pred['rois'][i][1]
                    y = pred['rois'][i][0]
                    w = pred['rois'][i][3] - x
                    h = pred['rois'][i][2] - y
                    pneu_box = [score, x*rf, y*rf, w*rf, h*rf]
                    boxes_list.append(pneu_box)
        if show:
            if num_box == 0:
                print("No pneumonia detected")
            else:
                print("{:d} boxes are above the min_conf".format(len(boxes_list)))
                for idx, box in enumerate(boxes_list):
                    print("box{:d}:".format(idx), box)
        return boxes_list


    def generate_submission(self, image_dir, save_fp, min_conf):
        """Generate submission for Kaggle competition.
        image_dir: Directory of testing images
        """     
        test_fps = tool.get_image_fps(image_dir)
        with open(save_fp, 'w') as file:
            file.write("patientId,PredictionString\n")
            for image_fp in tqdm(test_fps):
                image_id = tool.get_id(image_fp)
                line = image_id + ","
                boxes_list = self.predict(image_fp=image_fp,
                    show=False, min_conf=min_conf)
                boxes_str = tool.get_box_str(boxes_list)
                line += boxes_str
                file.write(line+"\n")


    def visualize(self, image_fp, gt_csv=None, save_fp=None,
                  show=False, min_conf=0.95):
        """Visualize the detected boxes and groundtruth boxes, if provided.
        Note: Green: Detected
              Red:  Groundtruth
        """
        boxes_list = self.predict(image_fp, min_conf=min_conf)
        image = tool.read_image(image_fp, 3)
        for i, box in enumerate(boxes_list):
            score = box[0]
            if score > min_conf:
                x_min = int(box[1])
                y_min = int(box[2])
                w = int(box[3])
                h = int(box[4])
                x_max = x_min + w
                y_max = y_min + h
                cv2.rectangle(image, (x_min, y_min), (x_max, y_max), (0, 255, 0), 3, 1)
                cv2.putText(image,str(score),(x_min+10, y_min+10), cv2.FONT_HERSHEY_PLAIN, 3,(255,0,0),2,cv2.LINE_AA)
                print("**************************************")
                print("confidence level:", score, 'box: ', [x_min, y_min, w, h])
        
        if gt_csv is not None:
            assert os.path.exists(gt_csv)
            image_id = tool.get_id(image_fp)
            df = pd.read_csv(gt_csv)
            df_matched = df[df["patientId"]==image_id]
            assert df_matched.shape[0] != 0
            x = df_matched["x"].tolist()
            y = df_matched["y"].tolist()
            w = df_matched["width"].tolist()
            h = df_matched["height"].tolist()
            if not math.isnan(x[0]):
                for j in range(len(x)):
                    x_min, y_min, width, height = int(x[j]), int(y[j]), int(w[j]), int(h[j])
                    x_max, y_max = x_min + width, y_min + height
                    cv2.rectangle(image, (x_min, y_min), (x_max, y_max), (0, 0, 255), 3, 1)
                    
        if save_fp is not None:
            cv2.imwrite(save_fp, image)
        if show:
            plt.figure() 
            plt.imshow(image, cmap=plt.cm.gist_gray)
            plt.show()

#============================================================================
#============================================================================

    def csv_overlap(self, csv_file1, csv_file2, save_csv_fp=None, iou_thresh=0.0):
        """
        compute the overlapping boxes based on two csv files created 
        from 'MRCNN' prediction

        Input:
            csv_file1: the prediction of MRCNN model
            csv_file2: another prediction of MRCNN model
            iou_thresh: a threshold to control if save a box

        Output:
            return a csv file containing the overlapping boxes
        """

        assert os.path.exists(csv_file1)
        assert os.path.exists(csv_file2)

        csv1 = pd.read_csv(csv_file1) # read csv files
        csv2 = pd.read_csv(csv_file2) # read csv files
        assert set(csv1["patientId"].tolist()) == set(csv2["patientId"].tolist())

        overlap_csv = csv1.copy() # save the desirable overlap boxes
        for idx, row in csv1.iterrows():
            pid = row["patientId"]

            # empty overlap_csv for save
            overlap_csv.loc[overlap_csv["patientId"]==pid, "PredictionString"]=np.nan

            csv1_pred = list(csv1.loc[csv1["patientId"]==pid, "PredictionString"]) # list of string
            csv2_pred = list(csv2.loc[csv2["patientId"]==pid, "PredictionString"])

            if str(csv1_pred[0])=='nan' or str(csv2_pred[0])=='nan': continue

            csv1_pred = csv1_pred[0].split(' ') # list of sub-string
            csv2_pred = csv2_pred[0].split(' ')
            csv1_pred = [float(item) for item in csv1_pred if item !=''] # list of floating numbers
            csv2_pred = [float(item) for item in csv2_pred if item !='']

            boxes_str=''
            for Bi in range(len(csv1_pred) //5): # loop for each box (conf, x, y, w, h)
                for Bj in range(len(csv2_pred) //5):
                    box_i = csv1_pred[Bi*5:(Bi+1)*5]
                    box_j = csv2_pred[Bj*5:(Bj+1)*5]

                    if tool.iou(box_i[1:], box_j[1:]) > iou_thresh:
                        intersect_coord = self.box_intersect(box_i[1:],box_j[1:])
                        overlap_conf = (box_i[0]+box_j[0]) / 2.
                        [overlap_x, overlap_y, overlap_w, overlap_h] = intersect_coord
                        boxes_str += " {:.2f} {:f} {:f} {:f} {:f}".format(overlap_conf, overlap_x, overlap_y, overlap_w, overlap_h)

            overlap_csv.loc[overlap_csv["patientId"]==pid, "PredictionString"]=boxes_str
        if save_csv_fp is not None:
            overlap_csv.to_csv(save_csv_fp, index=False)
        else:
            raise Exception("Please provide a valid file to save result!")


    def csv_union(self, csv_file1, csv_file2, save_csv_fp=None, iou_thresh=0.0):
        """
        compute the union of boxes based on two csv files created 
        from 'MRCNN' prediction

        Input:
            csv_file1: the prediction of MRCNN model
            csv_file2: another prediction of MRCNN model
        Output:
            return a csv file containing the overlapping boxes
        """
        assert os.path.exists(csv_file1)
        assert os.path.exists(csv_file2)

        csv1 = pd.read_csv(csv_file1) # read csv files
        csv2 = pd.read_csv(csv_file2) # read csv files
        assert set(csv1["patientId"].tolist()) == set(csv2["patientId"].tolist())

        union_csv = csv1.copy() # save the desirable overlap boxes
        for idx, row in csv1.iterrows():
            pid = row["patientId"]
            union_csv.loc[union_csv["patientId"]==pid, "PredictionString"]=np.nan # empty union_csv for save

            csv1_pred = list(csv1.loc[csv1["patientId"]==pid, "PredictionString"]) # list of string
            csv2_pred = list(csv2.loc[csv2["patientId"]==pid, "PredictionString"])

            if str(csv1_pred[0])=='nan' and str(csv2_pred[0])!='nan':
                union_csv.loc[union_csv["patientId"]==pid, "PredictionString"]=str(csv2_pred[0])

            elif str(csv1_pred[0])!='nan' and str(csv2_pred[0])=='nan':
                union_csv.loc[union_csv["patientId"]==pid, "PredictionString"]=str(csv1_pred[0])

            elif str(csv1_pred[0])!='nan' and str(csv2_pred[0])!='nan': # very different from true 'union' operation
                csv1_pred_list = [float(item) for item in csv1_pred[0].split(' ') if item !=''] # list of floating numbers
                csv2_pred_list = [float(item) for item in csv2_pred[0].split(' ') if item !='']

                boxes_str, boxes_list = '', []
                for Bi in range(len(csv1_pred_list) //5): # loop for each box (conf, x, y, w, h)
                    for Bj in range(len(csv2_pred_list) //5):
                        box_i = csv1_pred_list[Bi*5:(Bi+1)*5]
                        box_j = csv2_pred_list[Bj*5:(Bj+1)*5]

                        # if larger than iou_thresh, save the intersection of boxes
                        if tool.iou(box_i[1:], box_j[1:]) > iou_thresh:
                            intersect_coord = self.box_intersect(box_i[1:],box_j[1:])
                            overlap_conf = round((box_i[0]+box_j[0]) / 2., 4)
                            boxes_list.append([overlap_conf]+intersect_coord)
                        else: # if less than iou_thresh, save both boxes
                            boxes_list.append(box_i)
                            boxes_list.append(box_j)

                box_idx = [str(it[1:]) for it in boxes_list]
                idx_deplicate = self.unique_list2_idx(box_idx) # deplicate idx ==0
                boxes_list = [bx for bx, idx in zip(boxes_list, idx_deplicate) if idx!=0]

                # get all boxes for certain patient image, and then delete overlapping boxes
                non_overlap_boxes_list = self.box_list_intersect(boxes_list, iou_thresh)

                for idx, boX in enumerate(non_overlap_boxes_list):
                    [cc, xx, yy, ww, hh] = boX
                    boxes_str += " {:.2f} {:f} {:f} {:f} {:f}".format(cc, xx, yy, ww, hh)
                union_csv.loc[union_csv["patientId"]==pid, "PredictionString"]=boxes_str
        if save_csv_fp is not None:
            union_csv.to_csv(save_csv_fp, index=False)
        else:
            raise Exception("Please provide a valid file to save result!")


    def csv_list_union(self, csv_list, save_csv_fp=None, iou_thresh=0.0):
        """
        compute the union of boxes based on multple csv files created 
        from 'MRCNN' prediction

        Input:
            csv_list: the list of cvs files, e.g., [csv1, csv2,...]
            save_csv_fp: a file to save the resulting csv
            iou_thresh: control the overlap of boxes of the same patient

        Output:
            return a csv file containing the union boxes
        """

        assert len(csv_list)>1
        for csv_file in csv_list:
            assert os.path.exists(csv_file)

        while len(csv_list)!=1:
            csv_file1 = csv_list[0]
            csv_file2 = csv_list[1]
            self.csv_union(csv_file1, csv_file2, save_csv_fp, iou_thresh)
            csv_list.remove(csv_file1)
            csv_list.remove(csv_file2)
            csv_list.append(save_csv_fp)


    def box_intersect(self, box1, box2):
        '''
        compute the intersection coordinates between 'box1' and 'box2'

        input:
            box1: [x,y,width, height]
            box1: [x,y,width, height]
        Output:
            box_intersect: [x,y,width, height]
        '''

        if type(box1) not in (list, tuple): raise Exception('TypeError!')
        if type(box2) not in (list, tuple): raise Exception('TypeError!')

        x1, y1, w1, h1 = box1
        x2, y2, w2, h2 = box2
        x_max1, y_max1 = x1 + w1, y1 + h1
        x_max2, y_max2 = x2 + w2, y2 + h2

        x_min_max, x_max_min = max([x1, x2]), min([x_max1, x_max2])
        y_min_max, y_max_min = max([y1, y2]), min([y_max1, y_max2])

        if x_max_min <= x_min_max or y_max_min <= y_min_max:
            return None
        else:
            overlap_x = x_min_max
            overlap_y = y_min_max
            overlap_w = x_max_min-x_min_max
            overlap_h = y_max_min-y_min_max
            return [overlap_x, overlap_y, overlap_w, overlap_h]


    def box_list_intersect(self, boxes_list, iou_thresh=0.0):
        '''
        for each patient image, there may be multple boxes after 'csv_union, it should be deleted
        boxes_list = [box1,box2,...], box1=[conf, x, y, w, h]
        '''
        assert len(boxes_list)!=0

        i = 0
        m = len(boxes_list)
        while i < (m-1):
            box0 = boxes_list[i]
            lst0 = boxes_list[(i+1):]
            iou_list = [tool.iou(box0[1:], item[1:]) for item in lst0]

            iou_bin = [iou<=iou_thresh for iou in iou_list]
            if np.all(iou_bin):
                break
            else:
                max_iou_idx = np.argmax(np.asarray(iou_list))
                olp = box_intersect(box0[1:], lst0[max_iou_idx][1:])
                olp = [(box0[0]+lst0[max_iou_idx][0])/2.]+olp
                boxes_list.remove(box0)
                boxes_list.remove(lst0[max_iou_idx])
                boxes_list.append(olp)
                i =0
                m = len(boxes_list)
        return boxes_list


    def unique_list2_idx(self, lst):
        '''
        find deplicate elements in [[...],[...],[...],...]
        '''
        assert len(lst)!=0
        idx_list = [1]*len(lst) # deplicate element ==> 0

        for i in range(len(lst)):
            element0 = lst[i]
            lst0 = lst[(1+i):]
            for idx, item in enumerate(lst0):
                if element0 == item:
                    idx_list[(idx+1)]=0
        return idx_list


    def visualize_csv(self, csv_file_list, image_folder, save_folder, img_ext='.dcm', min_conf=0.95):
        '''
        plot boxes on images based on the csv files

        Input:
            csv_file_list: provide boxes from different csv files
            image_folder: image files corresponding to 'patientId' of csv files
            save_folder: folder to save image 

        Output:
            all images with boxes of different colors
        '''
        
        assert len(csv_file_list)!=0

        # red       RGB(255,0,0)
        # blue      RGB(0,0,255)
        # green     RGB(0,255,0)
        # magenta   RGB(255,0,255)
        # violetred RGB(208,32,144)
        # yellow    RGB(255,255,0)
        color_dict={'red':(255,0,0), 'blue':(0,0,255), 'green':(0,255,0),  \
                    'magenta':(255,0,255),'yellow':(255,255,0), 'cyan':(0,238,238)}

        color_list = ['red', 'blue', 'green', 'magenta', 'yellow', 'cyan']

        if len(csv_file_list) > len(color_list):
            raise Exception("Too many csv files!!!")

        for csv_file, color in zip(csv_file_list, color_list[:len(csv_file_list)]):
            assert os.path.exists(csv_file)                                                # BGR==>RGB
            plot_csv_on_image(csv_file, image_folder, save_folder, img_ext, box_color=color_dict[color][::-1], min_conf=min_conf, show=False)
            image_folder = save_folder # plot another csv file on imagse that have been ploted by 'plot_csv_on_image'
            img_ext='.jpg'


    def plot_csv_on_image(self, csv_file, image_folder, save_folder=None, img_ext='.jpg', box_color=(0, 0, 255), min_conf=0.95, show=False):
        '''
        plot boxes on images based on the given csv file
        '''
        assert os.path.exists(csv_file)
        assert os.path.exists(image_folder)
        assert os.path.exists(save_folder)

        image_folder = (image_folder.replace('\\', '/')+'/').replace('//','/')
        save_folder = (save_folder.replace('\\', '/')+'/').replace('//','/')

        csv1 = pd.read_csv(csv_file) # read csv files
        for idx, row in csv1.iterrows():
            pid = row["patientId"]
            img_file = image_folder + pid + img_ext

            if os.path.exists(img_file):
                if img_ext==".dcm":
                    import pydicom
                    ds = pydicom.read_file(img_file)
                    image = ds.pixel_array
                    image = np.stack((image,)*3, -1)
                else:
                    image = cv2.imread(img_file)

            csv_boxes = list(csv1.loc[csv1["patientId"]==pid, "PredictionString"]) # list of string
            if type(csv_boxes[0]) == str:
                csv_boxes = csv_boxes[0].split(' ') # list of sub-string 
                csv_boxes = [float(item) for item in csv_boxes if item !=''] # list of floating numbers

                for Bi in range(len(csv_boxes) //5): # loop for each box (conf, x, y, w, h)
                    box_i = csv_boxes[Bi*5:(Bi+1)*5]

                    conf = round(box_i[0],4)
                    if conf > min_conf:
                        x1 = int(box_i[1])
                        y1 = int(box_i[2])
                        w = int(box_i[3])
                        h = int(box_i[4])

                        x2 = x1 + w 
                        y2 = y1 + h
                        cv2.rectangle(image, (x1, y1), (x2, y2), box_color, 3, 1)
                        cv2.putText(image,str(conf),(x1+10, y1+10), cv2.FONT_HERSHEY_PLAIN, 3,(255,0,0),2,cv2.LINE_AA)

                save_file = save_folder +'/'+ pid + '.jpg'
                cv2.imwrite(save_file, image)

                if show:
                    plt.figure() 
                    plt.imshow(image, cmap=plt.cm.gist_gray)
                    plt.show()


    def csv_filter_befor_classify(self, csv_pred_file, csv_classify_file, save_csv_fp=None, min_conf=0.95):
        '''
        according to 'csv_classify_file', make sure that patientId with positive label has at least one box
        input:
            csv_pred_file: csv file predicted by 'mrcnn' model
            csv_classify_file: csv file predicted by 'Densenet' model
            save_csv_fp: file to save the resulting csv
        '''

        assert os.path.exists(csv_pred_file)
        assert os.path.exists(csv_classify_file)

        csv_pred = pd.read_csv(csv_pred_file) # read csv files
        csv_classify = pd.read_csv(csv_classify_file) # read csv files
        assert set(csv_pred["patientId"].tolist()) == set(csv_classify["patientId"].tolist())

        target_csv = csv_pred.copy() # save the desirable overlap boxes
        for idx, row in csv_pred.iterrows():
            pid = row["patientId"]
            target_csv.loc[target_csv["patientId"]==pid, "PredictionString"]=np.nan # empty target_csv for save

            pid_pred = list(csv_pred.loc[csv_pred["patientId"]==pid, "PredictionString"]) # list of string
            pid_classfy = list(csv_classify.loc[csv_classify["patientId"]==pid, "Target"])

            if pid_classfy[0]==1 and str(pid_pred[0])!='nan':
                pid_pred_list = [float(item) for item in pid_pred[0].split(' ') if item !='']

                boxes_list=[]
                conf_list = [pid_pred_list[i*5] for i in range(len(pid_pred_list) //5)]
                conf_bin = [ conf < min_conf for conf in conf_list]
                if not np.all(conf_bin): # if all boex conf < min_conf, only save one box with max conf
                    max_conf_idx = np.argmax(conf_list)
                    boxes_list.append(pid_pred_list[max_conf_idx*5:(max_conf_idx+1)*5])
                else:
                    conf_bin=np.asarray(conf_bin, dtype='uint8')
                    idxs = np.where(conf_bin==0)[0] # greater than min_conf
                    [boxes_list.append(pid_pred_list[ii*5:(ii+1)*5]) for ii in idxs]

                boxes_str=''
                for boX in boxes_list:
                    [cc, xx, yy, ww, hh] = boX
                    boxes_str += " {:.2f} {:f} {:f} {:f} {:f}".format(cc, xx, yy, ww, hh)
                target_csv.loc[target_csv["patientId"]==pid, "PredictionString"]=boxes_str
        
        if save_csv_fp is not None:
            target_csv.to_csv(save_csv_fp, index=False)
        else:
            raise Exception("Please provide a valid file to save result!")



# ========================================



