import os
import shutil
import numpy as np
import keras.backend as k
from keras import losses
from keras.callbacks import Callback, LearningRateScheduler
from sklearn.metrics import roc_auc_score
from sklearn.metrics import log_loss


def lr_sched(initial_lr, mode="custom"):
    ''' learning rate scheduler '''
    def step_decay(epoch):
        return initial_lr * (0.1 ** np.floor(epoch/25))
    def custom(epoch):
        if epoch < 15:
            return initial_lr
        elif epoch >= 15 and epoch < 40:
            return initial_lr/10
        else:
            return initial_lr/100
    if mode == "step_decay":
        return LearningRateScheduler(step_decay)
    else:
        return LearningRateScheduler(custom)


class MyCallback(Callback):
    """ Customized callback """
    def __init__(self, sequence, weights_path, stats=None, workers=1):
        super(Callback, self).__init__()
        self.sequence = sequence
        self.workers = workers
        self.class_names = class_names
        self.weights_path = weights_path
        self.best_weights_path = os.path.join(os.path.dirname(weights_path), "best_weights.h5")
        self.best_auroc_log_path = os.path.join(os.path.dirname(weights_path),"best_auroc.log")
        self.aurocs = {}

    def on_epoch_end(self, epoch, logs={}):
        
        print("\n*********************************")
        self.stats["lr"] = float(kb.eval(self.model.optimizer.lr))
        print("current learning rate: %f" % (self.stats['lr']))
        y_hat = self.model.predict_generator(self.sequence, workers=self.workers)   
        y = self.sequence.get_y_true()
        
        print("*** epoch#%d dev auroc ***" % (epoch + 1))
        current_auroc = []
        for i in range(len(self.class_names)):
            try:    
                score = roc_auc_score(y[:, i],y_hat[:,i])
            except ValueError:
                score = 0
            self.aurocs[self.class_names[i]].append(score)
            current_auroc.append(score)
            print("%d. %s: %f" %((i+1), self.class_names[i], score))
        
        print("*********************************")
        mean_auroc = np.mean(current_auroc)
        print("mean auroc: %s" %(mean_auroc))
        if mean_auroc > self.stats["best_mean_auroc"]:
            print("update best auroc from %f to %f" % (self.stats['best_mean_auroc'], mean_auroc))
            shutil.copy(self.weights_path, self.best_weights_path)
            print(f"update log file: {self.best_auroc_log_path}")
            with open(self.best_auroc_log_path, "a") as f:
                f.write("(epoch#%d) auroc: %f, lr: %f\n" % ((epoch + 1), (mean_auroc), (self.stats['lr'])))
            print("update model file: %s -> %s" % (self.weights_path, self.best_weights_path))
            self.stats["best_mean_auroc"] = mean_auroc
        print("*********************************")
        return

