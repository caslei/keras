import os, glob, math, cv2, pandas as pd

import sys, numpy as np
sys.path.append("./toolbox")
import tool

from itertools import groupby


def csv_overlap(csv_file1, csv_file2, save_csv_fp=None, iou_thresh=0.5):
    """
    compute the overlapping boxes based on two csv files created 
    from 'MRCNN' prediction

    Input:
        csv_file1: the prediction of MRCNN model
        csv_file2: another prediction of MRCNN model
        iou_thresh: a threshold to control if save a box
    Output:
        return a csv file containing the overlapping boxes
    """
    assert os.path.exists(csv_file1)
    assert os.path.exists(csv_file2)

    csv1 = pd.read_csv(csv_file1) # read csv files
    csv2 = pd.read_csv(csv_file2) # read csv files
    assert set(csv1["patientId"].tolist()) == set(csv2["patientId"].tolist())

    overlap_csv = csv1.copy() # save the desirable overlap boxes

    for idx, row in csv1.iterrows():
        pid = row["patientId"]

        # empty overlap_csv for save
        overlap_csv.loc[overlap_csv["patientId"]==pid, "PredictionString"]=np.nan

        csv1_pred = list(csv1.loc[csv1["patientId"]==pid, "PredictionString"]) # list of string
        csv2_pred = list(csv2.loc[csv2["patientId"]==pid, "PredictionString"])

        if str(csv1_pred[0])=='nan' or str(csv2_pred[0])=='nan': continue

        csv1_pred = csv1_pred[0].split(' ') # list of sub-string 
        csv2_pred = csv2_pred[0].split(' ')

        csv1_pred = [float(item) for item in csv1_pred if item !=''] # list of floating numbers
        csv2_pred = [float(item) for item in csv2_pred if item !='']

        boxes_str=''
        for Bi in range(len(csv1_pred) //5): # loop for each box (conf, x, y, w, h)
            for Bj in range(len(csv2_pred) //5):
                box_i = csv1_pred[Bi*5:(Bi+1)*5]
                box_j = csv2_pred[Bj*5:(Bj+1)*5]

                if tool.iou(box_i[1:], box_j[1:]) > iou_thresh:
                    conf1, x_min_1, y_min_1, width_1, height_1 = box_i
                    conf2, x_min_2, y_min_2, width_2, height_2 = box_j

                    mean_conf = (conf1+conf2) / 2.
                    x_max_1, y_max_1 = x_min_1 + width_1, y_min_1 + height_1
                    x_max_2, y_max_2 = x_min_2 + width_2, y_min_2 + height_2

                    x_min_max, x_max_min = max([x_min_1, x_min_2]), min([x_max_1, x_max_2])
                    y_min_max, y_max_min = max([y_min_1, y_min_2]), min([y_max_1, y_max_2])

                    overlap_c = mean_conf
                    overlap_x = x_min_max
                    overlap_y = y_min_max
                    overlap_w = x_max_min-x_min_max
                    overlap_h = y_max_min-y_min_max
                    # boxes_str += f" {overlap_c} {overlap_x} {overlap_y} {overlap_w} {overlap_h}"
                    boxes_str += " {:.2f} {:.0f} {:.0f} {:.0f} {:.0f}".format(overlap_c, overlap_x, overlap_y, overlap_w,overlap_h)
        # print(boxes_str)
        overlap_csv.loc[overlap_csv["patientId"]==pid, "PredictionString"]=boxes_str
    if save_csv_fp is not None:
        overlap_csv.to_csv(save_csv_fp, index=False)
    else:
        raise Exception("Please provide a valid file to save result!")


def visualize_csv(csv_file_list, image_folder, save_folder, file_ext, min_conf=0.95):
    '''
    plot boxes on images based on the csv files

    Input:
        csv_file_list: provide boxes from different csv files
        image_folder: image files corresponding to 'patientId' of csv files
        save_folder: folder to save image 

    Output:
        all images with boxes of different colors
    '''
    
    assert len(csv_file_list)!=0

    # red       RGB(255,0,0)
    # blue      RGB(0,0,255)
    # green     RGB(0,255,0)
    # magenta   RGB(255,0,255)
    # violetred RGB(208,32,144)
    # yellow    RGB(255,255,0)
    color_dict={'green':(0,255,0), 'magenta':(255,0,255),'blue':(0,0,255), 'red':(255,0,0),  \
                'yellow':(255,255,0), 'cyan':(0,238,238), 'black':(0,0,0) }

    color_list = ['red', 'blue', 'green', 'magenta', 'yellow', 'cyan', 'black']

    if len(csv_file_list) > len(color_list):
        raise Exception("Too many csv files!!!")

    for csv_file, color in zip(csv_file_list, color_list[:len(csv_file_list)]):
        assert os.path.exists(csv_file)
        # print(color_list[:len(csv_file_list)], color)
        plot_csv_on_image(csv_file, image_folder, save_folder, file_ext, box_color=color_dict[color][::-1], min_conf=min_conf, show=False)
        image_folder = save_folder # plot another csv file on imagse that have been ploted by 'plot_csv_on_image'
        file_ext='.jpg'


def plot_csv_on_image(csv_file, image_folder, save_folder=None, file_ext='.jpg', box_color=(0, 0, 255), min_conf=0.95, show=False):
    '''
    plot boxes on images based on the given csv file
    '''
    assert os.path.exists(csv_file)
    assert os.path.exists(image_folder)
    assert os.path.exists(save_folder)

    image_folder = (image_folder.replace('\\', '/')+'/').replace('//','/')
    save_folder = (save_folder.replace('\\', '/')+'/').replace('//','/')

    csv1 = pd.read_csv(csv_file) # read csv files
    for idx, row in csv1.iterrows():
        pid = row["patientId"]
        img_file = image_folder + pid + file_ext

        if os.path.exists(img_file):
            if file_ext==".dcm":
                import pydicom
                ds = pydicom.read_file(img_file)
                image = ds.pixel_array
                image = np.stack((image,)*3, -1)
            else:
                image = cv2.resize(cv2.imread(img_file), (1024,1024))

        csv_boxes = list(csv1.loc[csv1["patientId"]==pid, "PredictionString"]) # list of string
        # os.system("pause")
        if type(csv_boxes[0])==str: #  not math.isnan(csv_boxes[0])
            csv_boxes = csv_boxes[0].split(' ') # list of sub-string 
            csv_boxes = [float(item) for item in csv_boxes if item !=''] # list of floating numbers

            for Bi in range(len(csv_boxes) //5): # loop for each box (conf, x, y, w, h)
                box_i = csv_boxes[Bi*5:(Bi+1)*5]

                conf = round(box_i[0],4)
                if conf > min_conf:
                    x1 = int(box_i[1])
                    y1 = int(box_i[2])
                    w = int(box_i[3])
                    h = int(box_i[4])

                    x2 = x1 + w 
                    y2 = y1 + h
                    cv2.rectangle(image, (x1, y1), (x2, y2), box_color, 3, 1)
                    cv2.putText(image,str(conf),(x1+10, y1+10), cv2.FONT_HERSHEY_PLAIN, 3, box_color, 2, cv2.LINE_AA) # (255,0,0)

        save_file = save_folder +'/'+ pid + '.jpg'
        cv2.imwrite(save_file, image)

        if show:
            plt.figure() 
            plt.imshow(image, cmap=plt.cm.gist_gray)
            plt.show()


def csv_gt_to_csv_submission(gt_csv_file, save_file=None):
    '''    convert 'csv_gt' to 'csv_submission'    '''
    assert os.path.exists(gt_csv_file)
    file=open(save_file, 'w')
    file.write("patientId,PredictionString\n")

    pid_list =[]
    csv1 = pd.read_csv(gt_csv_file) # read csv files
    for idx, row in csv1.iterrows():
        pid = row["patientId"]
        
        pid_list.append(pid)
        csv_target = list(csv1.loc[csv1["patientId"]==pid, "Target"]) # list of string
        # os.system("pause")
        boxes_str=''
        boxes_str += pid 
        boxes_str += ","
        if csv_target[0]==1: #  target==1
            gt_x = list(csv1.loc[csv1["patientId"]==pid, "x"])# a list of [x1,x2,...]
            gt_y = list(csv1.loc[csv1["patientId"]==pid, "y"])
            gt_w = list(csv1.loc[csv1["patientId"]==pid, "width"])
            gt_h = list(csv1.loc[csv1["patientId"]==pid, "height"])
            gt_box = [(1.0, x, y, w, h) for x,y,w,h in zip(gt_x,gt_y,gt_w,gt_h)]


        pid_idx = list(np.where(np.array(pid_list)==pid)[0])
        if len(pid_idx)==1 and len(gt_box)!=0:
            for boX in gt_box:
                [cc, xx, yy, ww, hh] = boX
                boxes_str += " {:.2f} {:.0f} {:.0f} {:.0f} {:.0f}".format(cc, xx*2, yy*2, ww*2, hh*2)
            file.write(boxes_str+"\n")




def csv_union(csv_file1, csv_file2, save_csv_fp=None, iou_thresh=0.25):
    """
    compute the union of boxes based on two csv files created 
    from 'MRCNN' prediction

    Input:
        csv_file1: the prediction of MRCNN model
        csv_file2: another prediction of MRCNN model

    Output:
        return a csv file containing the overlapping boxes
    """
    assert os.path.exists(csv_file1)
    assert os.path.exists(csv_file2)

    csv1 = pd.read_csv(csv_file1) # read csv files
    csv2 = pd.read_csv(csv_file2) # read csv files
    assert set(csv1["patientId"].tolist()) == set(csv2["patientId"].tolist())

    union_csv = csv1.copy() # save the desirable overlap boxes
    for idx, row in csv1.iterrows():
        pid = row["patientId"]
        union_csv.loc[union_csv["patientId"]==pid, "PredictionString"]=np.nan # empty union_csv for save

        csv1_pred = list(csv1.loc[csv1["patientId"]==pid, "PredictionString"]) # list of string
        csv2_pred = list(csv2.loc[csv2["patientId"]==pid, "PredictionString"])

        if str(csv1_pred[0])=='nan' and str(csv2_pred[0])!='nan':
            union_csv.loc[union_csv["patientId"]==pid, "PredictionString"]=str(csv2_pred[0])

        elif str(csv1_pred[0])!='nan' and str(csv2_pred[0])=='nan':
            union_csv.loc[union_csv["patientId"]==pid, "PredictionString"]=str(csv1_pred[0])

        elif str(csv1_pred[0])!='nan' and str(csv2_pred[0])!='nan': # very different from true 'union' operation
            csv1_pred_list = [float(item) for item in csv1_pred[0].split(' ') if item !=''] # list of floating numbers
            csv2_pred_list = [float(item) for item in csv2_pred[0].split(' ') if item !='']

            boxes_str=''
            boxes_list=[]
            for Bi in range(len(csv1_pred_list) //5): # loop for each box (conf, x, y, w, h)
                for Bj in range(len(csv2_pred_list) //5):
                    box_i = csv1_pred_list[Bi*5:(Bi+1)*5]
                    box_j = csv2_pred_list[Bj*5:(Bj+1)*5]

                    # if larger than iou_thresh, save the intersection of boxes
                    if tool.iou(box_i[1:], box_j[1:]) > iou_thresh:
                        intersect_coord = box_intersect(box_i[1:],box_j[1:])
                        overlap_conf = round((box_i[0]+box_j[0]) / 2., 4)
                        boxes_list.append([overlap_conf]+intersect_coord)
                    else: # if less than iou_thresh, save both boxes
                        boxes_list.append(box_i)
                        boxes_list.append(box_j)

            box_idx = [str(it[1:]) for it in boxes_list]
            idx_deplicate = unique_list2_idx(box_idx) # deplicate idx ==0
            boxes_list = [bx for bx, idx in zip(boxes_list, idx_deplicate) if idx!=0]

            # get all boxes for certain patient image, and then delete overlapping boxes
            non_overlap_boxes_list = box_list_intersect(boxes_list, iou_thresh)

            for idx, boX in enumerate(non_overlap_boxes_list):
                [cc, xx, yy, ww, hh] = boX
                # boxes_str += f" {cc} {xx} {yy} {ww} {hh}"
                boxes_str += " {:.2f} {:.0f} {:.0f} {:.0f} {:.0f}".format(cc, xx, yy, ww, hh)
            union_csv.loc[union_csv["patientId"]==pid, "PredictionString"]=boxes_str
    if save_csv_fp is not None:
        union_csv.to_csv(save_csv_fp, index=False)
    else:
        raise Exception("Please provide a valid file to save result!")


def csv_list_union(csv_list, save_csv_fp=None, iou_thresh=0.0):
        """
        compute the union of boxes based on multple csv files created 
        from 'MRCNN' prediction

        Input:
            csv_list: the list of cvs files, e.g., [csv1, csv2,...]
            save_csv_fp: a file to save the resulting csv
            iou_thresh: control the overlap of boxes of the same patient

        Output:
            return a csv file containing the union boxes
        """

        assert len(csv_list)>1
        for csv_file in csv_list:
            assert os.path.exists(csv_file)

        while len(csv_list)!=1:
            csv_file1 = csv_list[0]
            csv_file2 = csv_list[1]
            csv_union(csv_file1, csv_file2, save_csv_fp, iou_thresh)
            csv_list.remove(csv_file1)
            csv_list.remove(csv_file2)
            csv_list.append(save_csv_fp)


def box_intersect(box1, box2):
    '''
    compute the intersection coordinates between 'box1' and 'box2'

    input:
        box1: [x,y,width, height]
        box1: [x,y,width, height]
    Output:
        box_intersect: [x,y,width, height]
    '''
    if type(box1) not in (list, tuple): raise Exception('TypeError!')
    if type(box2) not in (list, tuple): raise Exception('TypeError!')

    x1, y1, w1, h1 = box1
    x2, y2, w2, h2 = box2
    x_max1, y_max1 = x1 + w1, y1 + h1
    x_max2, y_max2 = x2 + w2, y2 + h2

    x_min_max, x_max_min = max([x1, x2]), min([x_max1, x_max2])
    y_min_max, y_max_min = max([y1, y2]), min([y_max1, y_max2])

    if x_max_min <= x_min_max or y_max_min <= y_min_max:
        return None
    else:
        overlap_x = x_min_max
        overlap_y = y_min_max
        overlap_w = x_max_min-x_min_max
        overlap_h = y_max_min-y_min_max
        return [overlap_x, overlap_y, overlap_w, overlap_h]

        
def box_list_intersect(boxes_list, iou_thresh=0.0):
    '''
    for each patient image, there may be multple boxes after 'csv_union, 
    the overlapping boxes should be deleted
    boxes_list = [box1,box2,...], box1=[conf, x, y, w, h]
    '''
    assert len(boxes_list)!=0
    if len(boxes_list) == 1: return boxes_list

    out_list=[]
    while len(boxes_list)!=1:
        box0 = boxes_list[0]
        lst0 = boxes_list[1:]
        iou_list = [tool.iou(box0[1:], item[1:]) for item in lst0]
        iou_bin = [iuu>iou_thresh for iuu in iou_list]

        if not np.any(iou_bin):
            out_list.append(box0)
            boxes_list.remove(box0)
        else:
            for ix, iu in enumerate(iou_list):
                if iu>iou_thresh:
                    olp = box_intersect(box0[1:], lst0[ix][1:])
                    olp = [(box0[0]+lst0[ix][0])/2.]+olp
                    boxes_list.remove(lst0[ix])
                    boxes_list.append(olp)
            boxes_list.remove(box0)
        if len(boxes_list)==1: out_list.append(boxes_list[0])
    return out_list


def unique_list2_idx(lst):
    '''
    find deplicate elements in [[...],[...],[...],...]
    '''
    assert len(lst)!=0
    idx_list = [1]*len(lst) # deplicate element ==> 0

    for i in range(len(lst)-1):
        element0 = lst[i]
        lst0 = lst[(1+i):]
        for j, item in enumerate(lst0):
            if element0 == item:
                idx_list[(j+i+1)]=0
    return idx_list



def csv_filter_befor_classify(csv_pred_file, csv_classify_file, save_csv_fp=None, min_conf=0.95):
    '''
    according to 'csv_classify_file', make sure that patientId with positive label has at least one box
    input:
        csv_pred_file: csv file predicted by 'mrcnn' model
        csv_classify_file: csv file predicted by 'Densenet' model
        save_csv_fp: file to save the resulting csv
    '''

    assert os.path.exists(csv_pred_file)
    assert os.path.exists(csv_classify_file)

    csv_pred = pd.read_csv(csv_pred_file) # read csv files
    csv_classify = pd.read_csv(csv_classify_file) # read csv files
    assert set(csv_pred["patientId"].tolist()) == set(csv_classify["patientId"].tolist())

    target_csv = csv_pred.copy() # save the desirable overlap boxes
    for idx, row in csv_pred.iterrows():
        pid = row["patientId"]
        target_csv.loc[target_csv["patientId"]==pid, "PredictionString"]=np.nan # empty target_csv for save

        pid_pred = list(csv_pred.loc[csv_pred["patientId"]==pid, "PredictionString"]) # list of string
        pid_classfy = list(csv_classify.loc[csv_classify["patientId"]==pid, "Target"])

        if pid_classfy[0]==1 and type(pid_pred[0])==str:
            pid_pred_list = [float(item) for item in pid_pred[0].split(' ') if item !='']

            boxes_list=[]
            conf_list = [pid_pred_list[i*5] for i in range(len(pid_pred_list) //5)]
            conf_bin = [ conf < min_conf for conf in conf_list]
            if np.all(conf_bin): # if all boex conf < min_conf, only save one box with max conf
                max_conf_idx = np.argmax(conf_list)
                boxes_list.append(pid_pred_list[max_conf_idx*5:(max_conf_idx+1)*5])
            else:
                conf_bin=np.asarray(conf_bin, dtype='uint8')
                idxs = np.where(conf_bin==0)[0] # greater than min_conf
                [boxes_list.append(pid_pred_list[ii*5:(ii+1)*5]) for ii in idxs]

            boxes_str=''
            for boX in boxes_list:
                [cc, xx, yy, ww, hh] = boX
                boxes_str += " {:.2f} {:.0f} {:.0f} {:.0f} {:.0f}".format(cc, xx, yy, ww, hh)
            target_csv.loc[target_csv["patientId"]==pid, "PredictionString"]=boxes_str
    
    if save_csv_fp is not None:
        target_csv.to_csv(save_csv_fp, index=False)
    else:
        raise Exception("Please provide a valid file to save result!")




def csv_filter_befor_classify1(csv_pred_file, csv_classify_file, save_csv_fp=None, min_conf=0.95):
    assert os.path.exists(csv_pred_file)
    assert os.path.exists(csv_classify_file)

    csv_pred = pd.read_csv(csv_pred_file) # read csv files
    csv_classify = pd.read_csv(csv_classify_file) # read csv files
    assert set(csv_pred["patientId"].tolist()) == set(csv_classify["patientId"].tolist())

    target_csv = csv_pred.copy() # save the desirable overlap boxes
    for idx, row in csv_pred.iterrows():
        pid = row["patientId"]
        target_csv.loc[target_csv["patientId"]==pid, "PredictionString"]=np.nan # empty target_csv for save

        pid_pred = list(csv_pred.loc[csv_pred["patientId"]==pid, "PredictionString"]) # list of string
        pid_classfy = list(csv_classify.loc[csv_classify["patientId"]==pid, "prob"])

        if pid_classfy[0]>0.35 and type(pid_pred[0])==str:
            pid_pred_list = [float(item) for item in pid_pred[0].split(' ') if item !='']

            boxes_list=[]
            conf_list = [pid_pred_list[i*5] for i in range(len(pid_pred_list) //5)]
            conf_bin = [ conf < min_conf for conf in conf_list]
            if np.all(conf_bin): # if all boex conf < min_conf, only save one box with max conf
                max_conf_idx = np.argmax(conf_list)
                boxes_list.append(pid_pred_list[max_conf_idx*5:(max_conf_idx+1)*5])
            else:
                conf_bin=np.asarray(conf_bin, dtype='uint8')
                idxs = np.where(conf_bin==0)[0] # greater than min_conf
                [boxes_list.append(pid_pred_list[ii*5:(ii+1)*5]) for ii in idxs]

            boxes_str=''
            for boX in boxes_list:
                [cc, xx, yy, ww, hh] = boX
                boxes_str += " {:.2f} {:.0f} {:.0f} {:.0f} {:.0f}".format(cc, xx, yy, ww, hh)
            target_csv.loc[target_csv["patientId"]==pid, "PredictionString"]=boxes_str

    if save_csv_fp is not None:
        target_csv.to_csv(save_csv_fp, index=False)
    else:
        raise Exception("Please provide a valid file to save result!")



#=====================================================

def csv_union1(csv_file_231, csv_file_1872, save_csv_fp=None, iou_thresh=0.25):
    assert os.path.exists(csv_file_231)
    assert os.path.exists(csv_file_1872)

    csv1 = pd.read_csv(csv_file_231) # read csv files
    csv2 = pd.read_csv(csv_file_1872) # read csv files
    assert set(csv1["patientId"].tolist()) == set(csv2["patientId"].tolist())

    union_csv = csv1.copy() # save the desirable overlap boxes
    for idx, row in csv1.iterrows():
        pid = row["patientId"]
        union_csv.loc[union_csv["patientId"]==pid, "PredictionString"]=np.nan # empty union_csv for save

        csv1_pred = list(csv1.loc[csv1["patientId"]==pid, "PredictionString"]) # list of string
        csv2_pred = list(csv2.loc[csv2["patientId"]==pid, "PredictionString"])

        if str(csv1_pred[0])=='nan': 
            continue

        elif str(csv1_pred[0])!='nan' and str(csv2_pred[0])=='nan':
            union_csv.loc[union_csv["patientId"]==pid, "PredictionString"]=str(csv1_pred[0])

        elif str(csv1_pred[0])!='nan' and str(csv2_pred[0])!='nan': # very different from true 'union' operation
            csv1_pred_list = [float(item) for item in csv1_pred[0].split(' ') if item !=''] # list of floating numbers
            csv2_pred_list = [float(item) for item in csv2_pred[0].split(' ') if item !='']

            boxes_str=''
            boxes_list=[]
            for Bi in range(len(csv1_pred_list) //5): # loop for each box (conf, x, y, w, h)
                for Bj in range(len(csv2_pred_list) //5):
                    box_i = csv1_pred_list[Bi*5:(Bi+1)*5]
                    box_j = csv2_pred_list[Bj*5:(Bj+1)*5]

                    # if larger than iou_thresh, save the intersection of boxes
                    if tool.iou(box_i[1:], box_j[1:]) > iou_thresh:
                        intersect_coord = box_intersect(box_i[1:],box_j[1:])
                        overlap_conf = round((box_i[0]+box_j[0]) / 2., 4)
                        boxes_list.append([overlap_conf]+intersect_coord)
                    else: # if less than iou_thresh, save both boxes
                        boxes_list.append(box_i)
                        # boxes_list.append(box_j)

            box_idx = [str(it[1:]) for it in boxes_list]
            idx_deplicate = unique_list2_idx(box_idx) # deplicate idx ==0
            boxes_list = [bx for bx, idx in zip(boxes_list, idx_deplicate) if idx!=0]

            # get all boxes for certain patient image, and then delete overlapping boxes
            non_overlap_boxes_list = box_list_intersect(boxes_list, iou_thresh)

            for idx, boX in enumerate(non_overlap_boxes_list):
                [cc, xx, yy, ww, hh] = boX
                # boxes_str += f" {cc} {xx} {yy} {ww} {hh}"
                boxes_str += " {:.2f} {:.0f} {:.0f} {:.0f} {:.0f}".format(cc, xx, yy, ww, hh)
            union_csv.loc[union_csv["patientId"]==pid, "PredictionString"]=boxes_str
    if save_csv_fp is not None:
        union_csv.to_csv(save_csv_fp, index=False)
    else:
        raise Exception("Please provide a valid file to save result!")


def csv_list_union1(csv_list, save_csv_fp=None, iou_thresh=0.0):
        assert len(csv_list)>1
        for csv_file in csv_list:
            assert os.path.exists(csv_file)

        while len(csv_list)!=1:
            csv_file1 = csv_list[0]
            csv_file2 = csv_list[1]
            csv_union1(csv_file1, csv_file2, save_csv_fp, iou_thresh)
            csv_list.remove(csv_file1)
            csv_list.remove(csv_file2)
            csv_list.append(save_csv_fp)        

#=============================================================================
#=============================================================================
def csv_gt_to_csv_submission_test():
    csv_gt = 'E:\\CTdata\\RSNA\\csv_dataset\\train_p.csv'
    csv_sb = 'E:\\CTdata\\RSNA\\train_p_new_format.txt'
    csv_gt_to_csv_submission(csv_gt, csv_sb)

def csv_overlap_test():
    csv_file1 = 'F:/han mrcnn/0.188.csv'
    csv_file2 = 'F:/han mrcnn/0.179.csv'
    overlap_csv = 'F:/han mrcnn/overlap_csv.csv'
    csv_overlap(csv_file1, csv_file2, overlap_csv, iou_thresh=0.01)


def visualize_csv_test():
    # csv_file1 = "E:/1.1784.csv"
    # csv_file2 = 'G:/han mrcnn/pu/1.1470_1.1581_1.1872_1.1784_conf945_lucy9_0.4.csv'
    # csv_file3 = 'G:/han mrcnn/pu/1.1470_1.1581_1.1872_1.1784_conf945_lucy9_0.35.csv'
    # csv_file3 = "G:/han mrcnn/pu/0.231.csv"
    # csv_file4 = "G:/han mrcnn/pu/0.228.csv"
    csv_list = [
            # csv_file3, csv_file2,
            # "G:\\han mrcnn\\pu\\1.1784_conf80_class_with_conf945_lucy9_0.35.csv",
            # "G:\\han mrcnn\\pu\\1.1581_conf80_class_with_conf945_lucy9_0.35.csv",
            # "G:\\han mrcnn\\pu\\1.1872_conf80_class_with_conf945_lucy9_0.35.csv",
            # "G:\\han mrcnn\\pu\\1.1470_conf80_class_with_conf945_lucy9_0.35.csv",
            # "G:\\han mrcnn\\pu\\bestModel\\1.1091_conf80_class_with_conf945_lucy2.csv",
            # "G:\\han mrcnn\\pu\\bestModel\\1.1532_conf80_class_with_conf945_lucy2.csv",
            # "G:\\han mrcnn\\pu\\bestModel\\1.1537_conf80_class_with_conf945_lucy2.csv",
            # "G:\\han mrcnn\\pu\\bestModel\\1.1470_conf80_class_with_conf945_lucy2.csv",
            # "G:\\han mrcnn\\pu\\bestModel\\1.1872_conf80_class_with_conf945_lucy2.csv",
            "G:\\han mrcnn\\pu\\bestModel\\union_new_0.231_1.1872.csv",
            "G:\\han mrcnn\\pu\\bestModel\\0.231_new.csv",

            ]

    # csv_file2 = "E:/CTdata/RSNA/csv_dataset/test_p_new_format2.csv"
    # csv_file3 = "E:/CTdata/RSNA/forPatchClassify/test_p_class_prob0.4.csv"
    # csv_file3 = "E:/CTdata/RSNA/forPatchClassify/1.1872_conf80_negative_class_prob0.4.csv"
    # csv_file_list = [csv_file2, csv_file3]

    image_folder = "E:/CTdata/RSNA/stage_1_test_images"
    # image_folder = "E:/CTdata/RSNA/forPatchClassify/part1"
    save_folder = 'C:/users/lwang/Desktop/tmp/0.231vs0.231_1.1872_new'
    visualize_csv(csv_list, image_folder, save_folder, file_ext='.dcm', min_conf=0.0001)


def plot_csv_on_image_test():
    # csv_file = 'E:/han mrcnn/csv_union_0.199_0.187=0.202.csv'
    csv_file = 'E:/han mrcnn/csv_union_0.199_0.187.csv'
    image_folder = "E:/han mrcnn/stage_1_test_images"
    save_folder = 'C:/users/wlei/Desktop/tmp/visualize_csv'
    plot_csv_on_image(csv_file, image_folder, save_folder=save_folder, file_ext='.dcm', box_color=(0, 0, 255), min_conf=0.5, show=False)


def csv_union_test():
    csv_file1 = 'F:/han mrcnn/0.188.csv'
    csv_file2 = 'F:/han mrcnn/0.179.csv'
    overlap_csv = 'F:/han mrcnn/csv_union.csv'
    csv_union(csv_file1, csv_file2, overlap_csv, iou_thresh=0.05)


def csv_list_union_test():
    csv_file1 = "E:/han mrcnn/pu/1.1470_conf80_class_with_conf945_lucy8_0.4.csv"
    csv_file2 = "E:/han mrcnn/pu/1.1778_conf80_class_with_conf945_lucy8_0.4.csv"
    csv_file3 = "E:/han mrcnn/pu/1.1784_conf80_class_with_conf945_lucy8_0.4.csv"


    csv_list = [
            "G:\\han mrcnn\\pu\\0.231.csv",
            # "G:\\han mrcnn\\pu\\1.1784_conf80_class_with_conf945_lucy9_0.35.csv",
            # "G:\\han mrcnn\\pu\\1.1581_conf80_class_with_conf945_lucy9_0.35.csv",
            # "G:\\han mrcnn\\pu\\1.1872_conf80_class_with_conf945_lucy9_0.35.csv",
            # "G:\\han mrcnn\\pu\\1.1470_conf80_class_with_conf945_lucy9_0.35.csv",
            "G:\\han mrcnn\\pu\\bestModel\\1.1872_conf80_class_with_conf945_lucy9.csv",
            # "G:\\han mrcnn\\pu\\bestModel\\1.1532_conf80_class_with_conf945_lucy2.csv",
            # "G:\\han mrcnn\\pu\\bestModel\\1.1537_conf80_class_with_conf945_lucy2.csv",
            # "G:\\han mrcnn\\pu\\bestModel\\1.1470_conf80_class_with_conf945_lucy2.csv",
            # "G:\\han mrcnn\\pu\\bestModel\\1.1872_conf80_class_with_conf945_lucy2.csv",

            ]

    overlap_csv = 'G:\\han mrcnn\\pu\\bestModel\\union_new_0.231_1.1872.csv'
    csv_list_union1(csv_list, overlap_csv, iou_thresh=0.0005)


def csv_filter_befor_classify_test():
    csv_pred_file = 'E:/han mrcnn/pu/csv_union_1.1470_1.1778_1.1784.csv'
    csv_classify_file = "E:/han mrcnn/lucy-008-2.csv"
    save_csv_fp = "E:/han mrcnn/pu/csv_union_1.1470_1.1778_1.1784_classify_with_conf945_lucy8.csv"
    csv_filter_befor_classify(csv_pred_file, csv_classify_file, save_csv_fp, min_conf=0.945)


if __name__ == '__main__':
    if 0:
        print('Start to run "csv_overlap_test" function!\n')
        csv_overlap_test()
        print('It is over!\n')

    if 0:
        print('Start to run "plot_csv_on_image_test" function!\n')
        plot_csv_on_image_test()
        print('It is over!\n')

    if 1:
        print('Start to run "visualize_csv_test" function!\n')
        visualize_csv_test()
        
        # csv_gt = 'E:\\CTdata\\RSNA\\csv_dataset\\test_p.csv'
        # csv_sb = 'E:\\CTdata\\RSNA\\test_p_new_format.txt'
        # csv_gt_to_csv_submission(csv_gt, csv_sb)

        print('It is over!\n')

    if 0:
        print('Start to run "csv_union_test" function!\n')
        csv_union_test()
        plot_csv_on_image_test()
        print('It is over!\n')

    if 0:
        print('Start to run "csv_list_union_test" function!\n')
        csv_list_union_test()
        print('It is over!\n')

    if 0:
        print('Start to run "csv_filter_befor_classify_test" function!\n')
        csv_filter_befor_classify_test()
        print('It is over!\n')


    if 0:
        csv_file1 = "E:\\CTdata\\RSNA\\forPatchClassify\\1.1872_conf80.csv"
        csv_file2 = "E:\\CTdata\\RSNA\\forPatchClassify\\1.1928_conf80.csv"

        overlap_csv = "E:\\CTdata\\RSNA\\forPatchClassify\\union_1.1928_1.1872_conf80.csv"
        csv_list_union([csv_file1, csv_file2], overlap_csv, iou_thresh=0.945)

        # csv_file = "C:/users/lwang/Desktop/tmp/1.1872_conf80.csv"
        # image_folder = "E:/CTdata/RSNA/dataset_test/pneumonia"
        # save_folder = 'C:/users/lwang/Desktop/tmp/csv_detect'
        # plot_csv_on_image(csv_file, image_folder, save_folder, file_ext='.jpg', box_color=(0, 0, 255), min_conf=0.0)
    
        # csv_file = "C:/users/lwang/Desktop/tmp/1.1872_class_prob0.0.csv"
        # save_folder = 'C:/users/lwang/Desktop/tmp/csv_class'
        # plot_csv_on_image(csv_file, image_folder, save_folder, file_ext='.jpg', box_color=(0, 0, 255), min_conf=0.0)


