from my_detector import MyDetector


import sys
sys.path.append("./toolbox")
import tool
import glob
# from imgaug import augmenters as iaa

from func_test import csv_filter_befor_classify, csv_list_union_test

if __name__ == "__main__":
    csv_classify_file = "G:/han mrcnn/lucy9.csv"
    test_dir = "G:\\han mrcnn\\stage_1_test_images"

    if 0:
        # log_dir = "C:/Users/hliu/Desktop/DL/models/object detection/mrcnn/run2-4st"
        my_detector = MyDetector()
        # my_detector.train(log_dir)

        # # my_detector.load_model("C:/Users/hliu/Desktop/1.1571.h5")
        my_detector.load_model("G:\\han mrcnn\\pu\\bestModel\\mask_rcnn_pneumonia_0006_1.1091_pu.h5")
        my_detector.generate_submission(test_dir, "G:\\han mrcnn\\pu\\bestModel\\1.1091_conf80.csv", 0.80)

        csv_filter_befor_classify("G:\\han mrcnn\\pu\\bestModel\\1.1091_conf80.csv", csv_classify_file, "G:\\han mrcnn\\pu\\bestModel\\1.1091_conf80_class_with_conf945_lucy9.csv", min_conf=0.945)


        # my_detector.load_model("G:/han mrcnn/pu/mask_rcnn_pneumonia_0012_1.1872.h5")
        # my_detector.generate_submission(test_dir, "C:/users/lwang/Desktop/tmp/1.1872_conf80_train25684.csv", 0.80)
    ##########################################################################

    if False:
        my_detector = MyDetector()
        my_detector.load_model("C:/Users/hliu/Desktop/1.1571.h5")

        test_dir = "C:/Users/hliu/Desktop/DL/dataset/Kaggle/dataset_test/pneumonia"
        image_fps = glob.glob(test_dir+"/*.*")

        gt_csv = "C:/Users/hliu/Desktop/DL/dataset/Kaggle/csv_dataset/test_p.csv"
        save_dir = "C:/Users/hliu/Desktop/1.1571_p_0.9"
        
        for i, image_fp in enumerate(image_fps):
          print(i, " out of ", len(image_fps) )
          # image_id = tool.get_id(image_fp)
          # image_fp = "C:/Users/hliu/Desktop/DL/dataset/Kaggle/dataset_test/pneumonia/"+image_id+".jpg"

          # aug = iaa.ContrastNormalization(1.5)
          # aug = iaa.GaussianBlur((0, 1.2))
          # aug = iaa.Multiply(1.2, per_channel=0.5)
          # image = tool.visualize_aug(image_fp, aug, save_fp=save_dir+"/"+tool.get_id(image_fp)+".jpg")
          my_detector.visualize(image_fp, gt_csv, save_dir+"/"+tool.get_id(image_fp)+".jpg", show=False, min_conf=0.95)